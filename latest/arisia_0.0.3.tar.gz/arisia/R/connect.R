#' Connect Database
#'
#' 이 함수는 데이터베이스에서 에제를 불러와 반환합니다.
#' 사용 가능한 태그는 다음과 같습니다.
#' 1. 행렬(numpy, np, matrix, m)
#' 2. 데이터프레임(dataframe, df, $)
#' 3. 배열(array, ar, c)
#'
#' @param infile Path to the input file
#' @return numpy / dataframe parse
#' @export

connect <- function(ex, type){
  if(! ("RMySQL" %in% rownames(installed.packages()))) {install.packages("RMySQL")}
  library(RMySQL)
  # querry_generation
  query <- paste(c("select * from"), ex)
  print("예제를 불러오고 있습니다")
  echo <- paste(c("예제 :"), ex)
  q <- paste(c(echo), paste(c("출력 타입 : "), type))
  print(q)
  # database connect
  con<-dbConnect(MySQL(),user="view",password="example",dbname="example",host="database.arisia.space")
  # sending querry
  db<-dbSendQuery(con,query)
  data<-fetch(db,n=-1)
  # disconnect db
  dbDisconnect(con)
  # export data, parse database querry
  if(type=="numpy" | type=="np" | type=="matrix" | type=="m"){
    print("행렬(넘파이) 타입으로 반환합니다.")
    return(as.matrix(data))
  }
  else if(type=="dataframe" | type=="df" | type=="$"){
    print("데이터프레임 타입으로 반환합니다.")
    return(data)
  }
  else if(type=="array" | type=="ar" | type=="c"){
    print("배열 타입으로 반환합니다.")
    return(c(data))
  }
  else{
    print("타입이 잘못되었습니다. 문법을 확인하세요")
  }
}
#connect("test1","$")
#connect("test1", "c")
#connect("test1", "m")

#자체 db 연결 - 업데이트 예정
#connectdb <- function(ip, port, userid, userpw, database, type, querry){
#  con<-dbConnect(MySQL(),user=userid,password=userpw,dbname=database,host=ip)
#  query<-str(querry)
#  ports<-port
#  db<-dbSendQuery(con,query)
#  data<-fetch(db,n=-1)
#  dbDisconnect(con)
#  if(type=="numpy" | type=="np" | type=="matrix" | type=="m"){
#    print("행렬(넘파이) 타입으로 반환합니다.")
#    return(as.matrix(data))
#  }
#  else if(type=="dataframe" | type=="df" | type=="$"){
#    print("데이터프레임 타입으로 반환합니다.")
#    return(data)
#  }
#  else if(type=="array" | type=="ar" | type=="c"){
#    print("배열 타입으로 반환합니다.")
#    return(c(data))
#  }
#  else{
#    print("타입이 잘못되었습니다. 문법을 확인하세요")
#  }
#}
#connectdb('database.arisia.space', '3306', 'view', 'example', 'example', 'df', 'select * from test1;')

