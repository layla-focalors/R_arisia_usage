library(arisia)
connect("test1","df")
# 패키지 사용 테스트
#(23-08-12)
